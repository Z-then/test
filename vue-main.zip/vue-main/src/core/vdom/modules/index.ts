import directives from './directives'
import ref from './template-ref'

export default [ref, directives]
