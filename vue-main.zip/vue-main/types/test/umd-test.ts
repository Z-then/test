const vm = new Vue({
  template: '<div>hi</div>'
})

const options: Vue.ComponentOptions<Vue> = {
  template: '<div>test</div>'
}
